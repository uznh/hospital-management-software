package hospital;

import java.util.LinkedList;
import java.util.Scanner;

public class DoctorMainMenu {

    private static Doctor doctor;
    private static Admin admin = Admin.getInstance();
    private static Scanner scanner;

    public static void main(String[] args) {
        doctor = new Doctor(1, "Dr. Said Atwa");
        scanner = new Scanner(System.in);

        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Username: ");
            String username = scanner.nextLine();

            System.out.print("Password: ");
            String password = scanner.nextLine();

            loggedIn = doctor.login(username, password);

            if (!loggedIn) {
                System.out.println("Invalid credentials. Please try again.");
            }
        }

        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Doctor Menu ---");
            System.out.println("1. Choose Patient from List");
            System.out.println("2. Show Next Patient");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    choosePatientFromList();
                    break;
                case 2:
                    showNextPatient();
                    break;
                case 3:
                    System.out.println("Exiting the system...");

                    System.out.print("Press 'M' to go back to the main menu or any other key to exit: ");
                    String last = scanner.nextLine();

                    if (last.equalsIgnoreCase("M")) {
                        exit = true;
                    } else {
                        System.exit(0);
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        Main.main(args);

    }

    private static void choosePatientFromList() {
        LinkedList<Patient> patientList = admin.getPatientList();

        System.out.println("\n--- Choose Patient from List ---");

        if (patientList.isEmpty()) {
            System.out.println("No patients available.");
        } else {
            System.out.println("Patient List:");
            for (int i = 0; i < patientList.size(); i++) {
                Patient patient = patientList.get(i);
                System.out.println((i + 1) + ". " + patient.getName());
            }

            System.out.print("Enter the index of the patient to delete: ");
            int index = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            if (index >= 1 && index <= patientList.size()) {
                Patient chosenPatient = patientList.remove(index - 1);
                System.out.println("Patient '" + chosenPatient.getName() + "' has been removed.");
            } else {
                System.out.println("Invalid index. Please try again.");
            }
        }
    }

    private static void showNextPatient() {
        System.out.println("\n--- Show Next Patient ---");

        Patient nextPatient = doctor.getNextPatient();
        if (nextPatient != null) {
            System.out.println("Next Patient: " + nextPatient.getName());
        } else {
            System.out.println("No more patients in the queue.");
        }
    }
}
