package hospital;
/*
    This Project Made By:
    Said Atwa @0dcj
    Don't Forget to Follow !!
	
	https://www.instagram.com/0dcj/

	https://www.facebook.com/s3id.m
 */

/**
 *
 * @author said
 */
import java.util.LinkedList;

public class Doctor {

    private int id;
    private String name;
    private LinkedList<Patient> patients;

    public Doctor(int id, String name) {
        this.id = id;
        this.name = name;
        this.patients = new LinkedList<>();
    }

    public boolean login(String username, String password) {
        if (username.equals("said") && password.equals("123")) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Invalid credentials. Please try again.");
            return false;
        }
    }

    public void choosePatientFromList() {
        if (!patients.isEmpty()) {
            Patient patient = patients.poll();
            System.out.println("Patient chosen: " + patient);
        } else {
            System.out.println("No patients available.");
        }
    }
    
    public Patient getNextPatient() {
        if (!patients.isEmpty()) {
            return patients.peek();
        }
        return null;
    }

    public void showNextPatient() {
        if (!patients.isEmpty()) {
            Patient nextPatient = patients.peek();
            System.out.println("Next patient: " + nextPatient);
        } else {
            System.out.println("No patients available.");
        }
    }

    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    public void removePatient(Patient patient) {
        patients.remove(patient);
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LinkedList<Patient> getPatients() {
        return patients;
    }

    public void setPatients(LinkedList<Patient> patients) {
        this.patients = patients;
    }
    

    @Override
    public String toString() {
        return "Doctor{" + "id=" + id + ", name=" + name + ", patients=" + patients + '}';
    }
    
}
