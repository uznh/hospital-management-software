/*
    This Project Made By:
    Said Atwa @0dcj
    Don't Forget to Follow !!
	
	https://www.instagram.com/0dcj/

	https://www.facebook.com/s3id.m
 */
/**
 *
 * @author said
 */
package hospital;

import java.util.Scanner;

public class AdminMainMenu {

    private static Admin admin = Admin.getInstance();
    private static Scanner scanner;

    public static void main(String[] args) {
        scanner = new Scanner(System.in);

        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Username: ");
            String username = scanner.nextLine();

            System.out.print("Password: ");
            String password = scanner.nextLine();

            loggedIn = admin.login(username, password);

            if (!loggedIn) {
                System.out.println("Invalid credentials. Please try again.");
            }
        }

        boolean backToMainMenu = false;
        while (!backToMainMenu) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Add Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Edit Patient");
            System.out.println("4. Delete Patient");
            System.out.println("5. View All Patients");
            System.out.println("6. Register Patient to Doctor");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    addPatient();
                    break;
                case 2:
                    searchPatient();
                    break;
                case 3:
                    editPatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    viewAllPatients();
                    break;
                case 6:
                    registerPatientToDoctor();
                    break;

                case 7:
                    System.out.println("Exiting the system...");

                    System.out.print("Press 'M' to go back to the main menu or any other key to exit: ");
                    String last = scanner.nextLine();

                    if (last.equalsIgnoreCase("M")) {

                        //backToMainMenu = true;
                        Main.main(args);


                    } else {
                        System.exit(0);
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

    }
    

    private static void addPatient() {
        System.out.println("\n--- Add Patient ---");

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Address: ");
        String address = scanner.nextLine();

        System.out.print("Age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        System.out.print("Gender: ");
        String gender = scanner.nextLine();

        System.out.print("Disease Description: ");
        String diseaseDescription = scanner.nextLine();

        System.out.print("Department: ");
        String department = scanner.nextLine();

        admin.addPatient(name, address, age, gender, diseaseDescription, department);
        System.out.println("Patient added successfully.");
    }

    private static void searchPatient() {
        System.out.println("\n--- Search Patient ---");

        System.out.print("Enter patient name or ID: ");
        String input = scanner.nextLine();

        Patient patient = admin.searchPatient(input);
        if (patient != null) {
            System.out.println("Patient found: " + patient);
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void editPatient() {
        System.out.println("\n--- Edit Patient ---");

        System.out.print("Enter patient ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        Patient patient = admin.searchPatient(id);
        if (patient != null) {
            System.out.print("Name: ");
            String name = scanner.nextLine();

            System.out.print("Address: ");
            String address = scanner.nextLine();

            System.out.print("Age: ");
            int age = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            System.out.print("Gender: ");
            String gender = scanner.nextLine();

            System.out.print("Disease Description: ");
            String diseaseDescription = scanner.nextLine();

            System.out.print("Department: ");
            String department = scanner.nextLine();

            admin.editPatient(id, name, address, age, gender, diseaseDescription, department);
            System.out.println("Patient updated successfully.");
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void deletePatient() {
        System.out.println("\n--- Delete Patient ---");

        System.out.print("Enter patient ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        admin.deletePatient(id);
        System.out.println("Patient deleted successfully.");
    }

    private static void viewAllPatients() {
        System.out.println("\n--- All Patients ---");

        admin.viewAllPatients();
    }

    private static void registerPatientToDoctor() {
        System.out.println("\n--- Register Patient to Doctor ---");

        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        admin.registerPatientToDoctor(patientId, doctorId);
        System.out.println("Patient registered to doctor successfully.");
    }

}
