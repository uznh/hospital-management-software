/*
    This Project Made By:
    Said Atwa @0dcj
    Don't Forget to Follow !!
	
	https://www.instagram.com/0dcj/

	https://www.facebook.com/s3id.m
 */
package hospital;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        String logo = " __    __    ______        _______..______    __  .___________.    ___       __      \n"
                + "|  |  |  |  /  __  \\      /       ||   _  \\  |  | |           |   /   \\     |  |     \n"
                + "|  |__|  | |  |  |  |    |   (----`|  |_)  | |  | `---|  |----`  /  ^  \\    |  |     \n"
                + "|   __   | |  |  |  |     \\   \\    |   ___/  |  |     |  |      /  /_\\  \\   |  |     \n"
                + "|  |  |  | |  `--'  | .----)   |   |  |      |  |     |  |     /  _____  \\  |  `----.\n"
                + "|__|  |__|  \\______/  |_______/    | _|      |__|     |__|    /__/     \\__\\ |_______|\n"
                + "                                                                                     ";
        System.out.println(logo);
        System.out.println("Hospital Management Softwar By ## Said Atwa ##");
        Scanner in = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("What's Your Privilege ?");
            System.out.println("1. Admin");
            System.out.println("2. Doctor");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = in.nextInt();
            in.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    AdminMainMenu.main(args);
                    break;
                case 2:
                    DoctorMainMenu.main(args);
                    break;
                case 3:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        in.close();
        System.out.println("Thank you for using the Hospital Management Software.");
    }
}
