package hospital;
/*
    This Project Made By:
    Said Atwa @0dcj
    Don't Forget to Follow !!
	
	https://www.instagram.com/0dcj/

	https://www.facebook.com/s3id.m
 */

/**
 *
 * @author said
 */
import java.util.LinkedList;

public class Admin {

    private LinkedList<Patient> patients;
    private LinkedList<Doctor> doctors;
    private static Admin instance;

    // Make the constructor private so it can't be called from outside this class


    private Admin() {
        patients = new LinkedList<>();
        doctors = new LinkedList<>();
    }
    public static Admin getInstance() {
        if (instance == null) {
            instance = new Admin();
        }
        return instance;
    }

    public boolean login(String username, String password) {
        if (username.equals("admin") && password.equals("123")) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Invalid credentials. Please try again.");
            return false;
        }
    }

    public void addPatient(String name, String address, int age, String gender, String diseaseDescription, String department) {
        int id = patients.size() + 1; // Auto-increment ID
        Patient patient = new Patient(name, address, age, gender, diseaseDescription, department);
        patients.add(patient);
    }

    public Patient searchPatient(String name) {
        for (Patient patient : patients) {
            if (patient.getName().equalsIgnoreCase(name)) {
                return patient;
            }
        }
        return null;
    }

    public Patient searchPatient(int id) {
        for (Patient patient : patients) {
            if (patient.getId() == id) {
                return patient;
            }
        }
        return null;
    }

    public void editPatient(int id, String name, String address, int age, String gender, String diseaseDescription, String department) {
        for (Patient patient : patients) {
            if (patient.getId() == id) {
                patient.setName(name);
                patient.setAddress(address);
                patient.setAge(age);
                patient.setGender(gender);
                patient.setDiseaseDescription(diseaseDescription);
                patient.setDepartment(department);
                break;
            }
        }
    }

    public void deletePatient(int id) {
        Patient patientToRemove = null;
        for (Patient patient : patients) {
            if (patient.getId() == id) {
                patientToRemove = patient;
                break;
            }
        }
        if (patientToRemove != null) {
            patients.remove(patientToRemove);
        }
    }

    public void viewAllPatients() {
        for (Patient patient : patients) {
            System.out.println(patient);
        }
    }

    public void registerPatientToDoctor(int patientId, int doctorId) {
        Patient patient = searchPatient(patientId);
        Doctor doctor = searchDoctor(doctorId);
        if (patient != null && doctor != null) {
            doctor.addPatient(patient);
        }
    }
    
    public LinkedList<Patient> getPatientList() {
        return patients;
    }


    private Doctor searchDoctor(int id) {
        for (Doctor doctor : doctors) {
            if (doctor.getId() == id) {
                return doctor;
            }
        }
        return null;
    }
}
